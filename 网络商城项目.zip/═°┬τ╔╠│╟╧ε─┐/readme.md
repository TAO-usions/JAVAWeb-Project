# 第一个JAVAWEB项目。跟着培训班视频做的，适合初学者练手。
- 没有使用框架，采用servlet和JDBC进行开发
- sql文件夹里存放的是mysql建表，src文件夹里的是java代码，WEBCONTENT里的是页面。
- 实现了用户的注册、邮件激活、登陆、支付、商品的添加搜索和显示等功能

## 项目页面如下：
![image](images/index.png)
![image](images/login.png)
![image](images/item.png)
